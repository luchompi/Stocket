from django.apps import AppConfig


class BajasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.Bajas'
