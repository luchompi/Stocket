from django.contrib import admin
from .models import Funcionario,Proveedor
# Register your models here.
admin.site.register(Funcionario)
admin.site.register(Proveedor)

