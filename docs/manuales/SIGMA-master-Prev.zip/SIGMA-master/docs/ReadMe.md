Proyecto Sigma donde se implementa AdminLTE
1. Terminados Procedimientos de la Empresa (Sedes - Dependencias)
2. Terminados Procedimientos de Personas (Clientes - Proveedores)
3. Terminado Inventario
4. Terminadas Asginaciones
5. Terminados Traspasos - Nuevo! (Procedimiento no estaba disponible en 1ra Beta)