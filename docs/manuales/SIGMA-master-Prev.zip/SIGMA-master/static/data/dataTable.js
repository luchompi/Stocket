$(document).ready( function () {
    $('#datos').DataTable();
} );